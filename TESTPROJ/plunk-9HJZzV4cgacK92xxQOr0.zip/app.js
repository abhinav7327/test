var app = angular.module('plunker', []);

app.controller('MainCtrl', function($scope) {
  $scope.menuItems = [
			    {
			        "isNavItem": true,
			        "href": "#/dashboard.html",
			        "text": "Dashboard"
			    },
			    {
			        "isNavItem": true,
			        "href": "javascript:;",
			        "text": "AngularJS Features",
			        "subItems": [
			            {
			                "href": "#/ui_bootstrap.html",
			                "text": " UI Bootstrap"
			            },
			            {
			            	"subItems": [
					            {
					                "href": "#/ui_bootstrap.html",
					                "text": " Nested UI Bootstrap"
					            },
					            
					        ]
			            },
			            
			            
			        ]
			    },
			    {
			        "isNavItem": true,
			        "href": "javascript:;",
			        "text": "jQuery Plugins",
			        "subItems": [
			            {
			                "href": "#/form-tools",
			                "text": " Form Tools"
			            },
			            {
			                "isNavItem": true,
			                "href": "javascript:;",
			                "text": " Datatables",
			                "subItems": [
			                    {
			                        "href": "#/datatables/managed.html",
			                        "text": " Managed Datatables"
			                    },
			                    {
			                    	"subItems": [
							            {
							                "href": "#/ui_bootstrap.html",
							                "text": " Nested nested UI Bootstrap"
							            },
							            
					        		]
			                    },
			                    
			                ]
			            }
			        ]
			    }
			];

});
