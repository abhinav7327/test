JMeter
======

JMeter - WebSocket Sampler

Compiled binary can be downloaded from the Releases.

Please have a look at the [Wiki pages](https://github.com/maciejzaleski/JMeter-WebSocketSampler/wiki) for instructions on how to install the plug-in.
